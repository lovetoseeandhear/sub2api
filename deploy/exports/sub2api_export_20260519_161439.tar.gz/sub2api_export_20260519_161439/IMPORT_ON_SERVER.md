# Import sub2api data on target server

## 1) Upload package
Copy this export folder (or .tar.gz) to target server.

## 2) Restore PostgreSQL database
Assume target postgres container name: postgres

```bash
# create db if not exists
docker exec -i postgres psql -U root -d postgres -c 'CREATE DATABASE "sub2api";' || true

# restore
docker exec -i postgres pg_restore -U root -d sub2api --clean --if-exists --no-owner --no-privileges < sub2api_db.dump
```

## 3) Restore /app/data
Assume target sub2api container name: sub2api

```bash
# optional backup before overwrite
docker exec -i sub2api sh -lc 'cp -a /app/data /app/data.bak.$(date +%Y%m%d_%H%M%S)'

# copy exported data back
docker cp app_data/data/. sub2api:/app/data/
```

## 4) Restart sub2api
```bash
docker restart sub2api
```

## 5) Verify
- Login admin panel
- Check accounts/channels/settings
- Check `/health`
